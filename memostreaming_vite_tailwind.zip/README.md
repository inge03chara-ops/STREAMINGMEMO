# MEMOSTREAMING (Vite + React + Tailwind)

## Scripts
- `npm install` — instala dependencias
- `npm run dev` — entorno local
- `npm run build` — compila para producción
- `npm run preview` — vista previa local

## Despliegue en Vercel (rápido)
1. Crea una cuenta en https://vercel.com e instala **Vercel for GitHub** si quieres auto-deploy.2. Sube este proyecto a un repositorio de GitHub (por ejemplo, `memostreaming`).3. En Vercel, pulsa **New Project → Import Git Repository**, selecciona tu repo.4. Framework: **Other** (Vite), Build Command: `npm run build`, Output Directory: `dist`.5. Click en **Deploy**. Vercel generará una URL pública.
## Enlaces útiles
- WhatsApp directo: `https://wa.me/573169141004?text=Hola%20quiero%20MEMOSTREAMING`- Email: `mailto:inge03chara@gmail.com`- Pagos Nequi: 300 838 6156
